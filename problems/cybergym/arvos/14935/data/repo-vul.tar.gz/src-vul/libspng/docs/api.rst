.. _api:

API documentation
=================

.. toctree::
    :maxdepth: 1

    errors
    version
    context
    chunk
    decode
