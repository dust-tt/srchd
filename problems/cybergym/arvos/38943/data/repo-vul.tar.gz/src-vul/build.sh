./bootstrap --no-po
./configure --disable-shared --enable-debug --disable-nls
make -j$(nproc) all
cd fuzz
$CC $CFLAGS -c -I.. -I../src -ogdbm_fuzzer.o gdbm_fuzzer.c
$CXX $CFLAGS -ogdbm_fuzzer gdbm_fuzzer.o ../src/libgdbmapp.a ../src/.libs/libgdbm.a $LIB_FUZZING_ENGINE
cp gdbm_fuzzer $OUT
cp gdbm_fuzzer.rc $OUT
PATH=$SRC/gdbm/src:$PATH sh ./build_seed.sh -C seed
zip -rj "$OUT/gdbm_fuzzer_seed_corpus.zip" seed/
