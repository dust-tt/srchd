
cd ${SRC}/jbig2dec
./autogen.sh
make distclean
mkdir -p ${WORK}/jbig2dec
cd ${WORK}/jbig2dec
${SRC}/jbig2dec/configure
LDFLAGS="$CXXFLAGS" make -C ${WORK}/jbig2dec -j$(nproc)
fuzz_target=jbig2_fuzzer
$CXX $CXXFLAGS -std=c++11 -I$SRC/jbig2dec -fno-inline-functions     $SRC/jbig2_fuzzer.cc -o $OUT/$fuzz_target     $LIB_FUZZING_ENGINE ${WORK}/jbig2dec/.libs/libjbig2dec.a
exit 0
mv $SRC/{*.zip,*.dict,*.options} $OUT
if [ ! -f "${OUT}/${fuzz_target}_seed_corpus.zip" ]; then
  echo "missing seed corpus"
  exit 1
fi
if [ ! -f "${OUT}/${fuzz_target}.dict" ]; then
  echo "missing dictionary"
  exit 1
fi
if [ ! -f "${OUT}/${fuzz_target}.options" ]; then
  echo "missing options"
  exit 1
fi
