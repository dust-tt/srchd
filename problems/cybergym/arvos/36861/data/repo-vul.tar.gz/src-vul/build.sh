
exec ./build-aux/oss-fuzz.sh
