================================================================================
Doxygen
================================================================================

.. meta::
   :http-equiv=refresh: 0; url=doxygen/

`The Doxygen-based documentation is available here <doxygen/>`_
