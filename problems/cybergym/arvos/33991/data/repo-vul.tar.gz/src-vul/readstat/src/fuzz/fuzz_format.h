
readstat_parser_t *fuzzer_parser_init(const uint8_t *Data, size_t Size);
