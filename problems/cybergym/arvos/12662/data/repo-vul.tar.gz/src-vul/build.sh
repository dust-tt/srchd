
./autogen.sh
./configure --enable-static
make clean
make
make generate_corpus
./generate_corpus
zip $OUT/fuzz_format_dta_seed_corpus.zip corpus/dta*/test-case-*
zip $OUT/fuzz_format_por_seed_corpus.zip corpus/por/test-case-*
zip $OUT/fuzz_format_sav_seed_corpus.zip corpus/sav*/test-case-* corpus/zsav/test-case-*
zip $OUT/fuzz_format_sas7bcat_seed_corpus.zip corpus/sas7bcat/test-case-*
zip $OUT/fuzz_format_sas7bdat_seed_corpus.zip corpus/sas7bdat*/test-case-*
zip $OUT/fuzz_format_xport_seed_corpus.zip corpus/xpt*/test-case-*
READSTAT_FUZZERS="
    fuzz_format_dta     fuzz_format_por     fuzz_format_sav     fuzz_format_sas7bcat     fuzz_format_sas7bdat     fuzz_format_xport"
for fuzzer in $READSTAT_FUZZERS; do
    make ${fuzzer}
    cp ${fuzzer} $OUT/${fuzzer}
done
