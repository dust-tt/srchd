#! /usr/bin/env bash

autoreconf -i
