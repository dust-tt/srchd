
long dta_file_format_version(long format_code);
