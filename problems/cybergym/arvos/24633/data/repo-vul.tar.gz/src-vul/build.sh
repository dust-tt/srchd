
cd extras/fuzzing
make
