$SRC/miniz/tests/ossfuzz.sh
