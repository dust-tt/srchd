cd $SRC/wolfssl/
autoreconf -ivf
if [[ $CFLAGS = *sanitize=memory* ]]
then
    ./configure --enable-static --disable-crypttests --disable-examples --disable-asm
elif [[ $CFLAGS = *-m32* ]]
then
    ./configure --enable-static --disable-crypttests --disable-examples --disable-fastmath
else
    ./configure --enable-static --disable-crypttests --disable-examples
fi
make -j$(nproc)
export CFLAGS="$CFLAGS -I $(realpath .)"
export LDFLAGS="-L$(realpath src/.libs/)"
cd $SRC/wolfmqtt/
./autogen.sh
./configure --enable-static --disable-examples --enable-mqtt5
make -j$(nproc)
$CXX $CXXFLAGS     -std=c++17     -I $SRC/fuzzing-headers/include/     -I $SRC/wolfssl/     -I $SRC/wolfmqtt/     $SRC/wolfmqtt-fuzzers/fuzzer.cpp     $SRC/wolfmqtt/src/.libs/libwolfmqtt.a     $SRC/wolfssl/src/.libs/libwolfssl.a     $LIB_FUZZING_ENGINE     -o $OUT/wolfmqtt-fuzzer
